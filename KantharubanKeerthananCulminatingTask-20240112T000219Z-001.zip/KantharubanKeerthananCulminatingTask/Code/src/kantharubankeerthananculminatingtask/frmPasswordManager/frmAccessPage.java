/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
   
Author: Keerthanan Kantharuban
Date: Jun 8-19, 2023
Password Manager
   
    
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;


import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;


public class frmAccessPage extends JFrame implements ActionListener{
    
    //Declaring a int variable that will decrease each time the user gets the password wrong, set to 5
    int intTries = 5;
    //Delcaring a JLabel that will Welcome the User
    JLabel lblWelcome;
    
    JLabel lblInstructions; 
    //Declaring a JLabel that will ask the user for the password input
    JLabel lblPass; 
    //Declaring a PasswordField that will receive input of the password
    JPasswordField txtPass;
    //Declaring a JButton that will Login the user if the password is right
    JButton btnLogin; 
    //Declaring a JLabel that tell user the password is wrong
    JLabel lblWrongPassword;
    //Declaring a JButton that will Register the User
    JButton btnRegister; 
    //Declaring a JButton that will Quit 
    JButton btnQuit;
    //Declaring a JLabel that will add a Circle
    JLabel lblCircle;
    //Declaring a ImageIcon that will access the Circle
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");
    
    
    //Method that returns passsword from txt file, and return it.
    /**
     * 
     * @return master password 
     */
    public static String readMasterPassword(){
      String strMasterPassword = ""; //Setup string that will return the masterpassword string
      try{
        //Read from the file that contains the master password (MasterPassword)
        FileReader fr = new FileReader("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/MasterPassword.txt");
        BufferedReader br = new BufferedReader(fr); //Setup reader
        strMasterPassword = br.readLine();//Read the first line and define it to the variable strMasterPassword
      }
      catch(IOException e){
        e.printStackTrace(); //Print any errors
      }
     return strMasterPassword; //Return master password
  } 
    

    
    

    /**
     * 
     * @param alreadyUser is a Boolean
     */
    public frmAccessPage(Boolean alreadyUser){
      
      
      
      //Resize frame to 825x600
      resize(825,600);
      //Set the layour to nothing
      setLayout(null);
      //Set the background colour to ORANGE
      getContentPane().setBackground(Color.ORANGE);
      
      //Set up and add lblWelcome JLabel that will display "Welcome to Kiel's Password Manager" at top of screen in Monospaced font, bold and italics to screen
      lblWelcome = new JLabel();
      lblWelcome.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
      lblWelcome.setForeground(Color.white);
      lblWelcome.setText("Welcome to Kiel Password Manager");
      lblWelcome.setSize(600, 100);
      lblWelcome.setLocation(187, 10);
      add(lblWelcome);
      
      
      lblInstructions = new JLabel();
      lblInstructions.setFont(new Font("Monospaced", Font.BOLD, 12));
      lblInstructions.setForeground(Color.black);
      lblInstructions.setText("Please enter Master Password to continue, if you don't have one, please register!");
      lblInstructions.setSize(700, 100);
      lblInstructions.setLocation(120, 350);
      add(lblInstructions);
      
     
      //Set up and add lblPass JLabel that will display "Password" to the left middle of screen in Monospaced font bold to screen 
      lblPass = new JLabel();
      lblPass.setFont(new Font("Monospaced", 1, 18));
      lblPass.setForeground(Color.black);
      lblPass.setText("Password"); 
      lblPass.setSize(200, 200);
      lblPass.setLocation(87, 200);
      add(lblPass);
      
      //Set up and add txtPAss JPasswordField that will take input for a password which will read as black dots to the right of the lblPass to screen
      txtPass = new JPasswordField();
      txtPass.setText("");
      txtPass.setSize(350, 50);
      txtPass.setLocation(287, 275);
      add(txtPass);
      
      //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
      lblCircle = new JLabel();
      lblCircle.setText("");
      lblCircle.setSize(330, 350);
      lblCircle.setOpaque(false);
      lblCircle.setIcon(imgCircle);
      lblCircle.setLocation(600, 0);
      add(lblCircle);
      
      //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
      lblCircle2 = new JLabel();
      lblCircle2.setText("");
      lblCircle2.setSize(400,400);
      lblCircle2.setOpaque(false);
      lblCircle2.setIcon(imgCircle2);
      lblCircle2.setLocation(-110, 350);
      add(lblCircle2);
      
      //Set up and add btnLogin that will read button input of login which will move to the home page, add to lower part of screen
      btnLogin = new JButton();
      btnLogin.setText("Enter");
      btnLogin.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnLogin.setSize(200, 50);
      btnLogin.setLocation(337, 450);
      add(btnLogin);

      btnLogin.setActionCommand("login");
      btnLogin.addActionListener(this);
      add(btnLogin);
      
      //If the alreadyUser parameter is false
      if(!alreadyUser){
        //Set up and add btnRegister that will read button input of register which will move the register page, add under the login button
        btnRegister = new JButton();
        btnRegister.setText("New? Register");
        btnRegister.setFont(new Font("Serif", 1+Font.ITALIC, 15));
        btnRegister.setSize(175, 30);
        btnRegister.setLocation(352, 525);
        add(btnRegister);
  
        btnRegister.setActionCommand("register");
        btnRegister.addActionListener(this);
        add(btnRegister);
      }
      
      //Set up and add lblWrongPassword that will display if the password is wrong 
      lblWrongPassword = new JLabel();
      lblWrongPassword.setText("");
      lblWrongPassword.setFont(new Font("Monospaced", 1, 15));
      lblWrongPassword.setSize(400, 30);
      lblWrongPassword.setLocation(337, 350);
      add(lblWrongPassword);
      

      //Set up and add btnQuit that will read button input of quit which will stop the program, add to the top right of the screen
      btnQuit = new JButton();
      btnQuit.setText("QUIT");
      btnQuit.setFont(new Font("Monospaced", 1, 17));
      btnQuit.setSize(75, 30);
      btnQuit.setLocation(730, 5);
      add(btnQuit);

      
      btnQuit.setActionCommand("quit");
      btnQuit.addActionListener(this);
      add(btnQuit);
          
        
    }
    

    /**
     * @param e 
     */
    public void actionPerformed(ActionEvent e){
      //If the user presses the login button is pressed
      if(e.getActionCommand().equals("login")){
        //Convert the txtPass to a string and set it to string
        String strPasswordInput = txtPass.getText();
 
       //If the strPasswordInput is the same as the masterPassword inside the file
       if((strPasswordInput.compareTo(readMasterPassword()) == 0) && !strPasswordInput.equals("")){
          //Move the user to the home page
          frmHomePage frmHomePage = new frmHomePage(); 
          frmHomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          frmHomePage.setSize(825,600); //Set the size of frmHomePage
          frmHomePage.setVisible((true));
          //Stop the screen
          this.dispose();
          //Else if the password inputted in wrong
       } else {
           //Decrease the intTries counter by one
           intTries--;
           //Set the text to lblWrongPassword to display to it is a wrong master password, and the display the intTries
           lblWrongPassword.setText("Wrong Master Password " + (intTries) + " tries left");
           //If the intTries is 0 meaning the user has exhausted all attempts
           if(intTries == 0){
               //Stop this screen which will stop the entire program
               this.dispose();
               
           }
           
       }
        
       
       //If the user pressed the register button
      } else if (e.getActionCommand().equals("register")){
        //Open the register GUI
        frmRegisterPage frmRegisterPage = new frmRegisterPage();  
        frmRegisterPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmRegisterPage.setSize(825,600);
        frmRegisterPage.setVisible((true));
        //Close this screen
        this.dispose();
        
        //If the user chooses to quit the program
      } else if (e.getActionCommand().equals("quit")){
        //Stop this creen which will stop the entire program
        this.dispose();
      }
    }    
}

