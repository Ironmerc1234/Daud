/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;


import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;


public class frmShowPasswordPage extends JFrame implements ActionListener{
  final String strFontMono = "Monospaced";
  final String strFontSerif = "Serif";
  
  public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
  //Declaring an integer intIndex variable that count how much passwords there are in the dataBase 
  int intIndex = 0;
  //Start a 2 dimensional array that will have a limit of 500 passwords, and 2 field which is the site and password
  String[][] passwords = new String[500][2];
  //Set a boolSortAlpha to true which will sort back and forth between two sorting methods, if it's false it will sort according to added date, and if it's true it will sort according to alphabet letter
  boolean boolSortAlpha = true; 
  //Set another 2d array called originalPassword which will store the actual amount of passwords and sites without 500 empty fields
  String [][] originalPasswords;
  
  Login[] originalPasswords1; 
  
  /**
   * 
   * @return passwords
   */
  public Login[] DatabaseArrConversion() {
    

  try {
  
    // Reset the FileReader object to the beginning of the file
    FileReader fr = new FileReader("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/passwordDatabase.txt");
    // Reset the BufferedReader object with the new FileReader object
    BufferedReader br = new BufferedReader(fr);
    // Read the first line from the file
    String line = br.readLine();
    // Declare an index variable to keep track of the array position
    
    //While the read line does not equal null
    while (line != null) {
      //Set a new array to where it is a string field set to the two fields which are the site and password
      String[] fields = line.split(",");
      //Set passwords at intIndex, and at the site field to fields at 0
      passwords[intIndex][0] = fields[0];
      //Set passwords at intIndex, and at the passwords field to fields at 1
      passwords[intIndex][1] = fields[1];
      //Add 1 to intIndex each
      intIndex++;
      //Read line
      line = br.readLine();
    }
    //Close the fileReader
    br.close();
    
    } catch (IOException e){
      //Print any exceptions
      e.printStackTrace();
    }
  
    //Set original passwords to a how much passwords and site there were, and have 2 fields to store the password and site
    originalPasswords1 = new Login[intIndex];
    //Start a for loop that will stop at intIndex, which is the end of the array
    for (int i = 0; i < intIndex; i++) {
        //Set the original passwords at i and in the site field to the site field of passwords at i
    	
    	String tempUser = passwords[i][0];
    	String tempPass = passwords[i][1];
    	
    	
        originalPasswords1[i] = new Login(tempUser, tempPass);
    }
  
    //Return the originalPasswords
    return originalPasswords1;
  }
  

  




  
    //Declare a JLabel that will welcome the user to show passwords 
    JLabel lblShowPasswords;
    //Declare a JButton that will exit if user presses it
    JButton btnExit; 
    //Declare a JButton that will move user to frmSearchSpecificPage if user presses it
    JButton btnSearchSpecificPass;
    //Declare a JButton that will order the JTabel 
    JButton btnOrder;
    //Declare a JTable that will create the site and password table
    JTable table;
    //Declare a scrollPane that will display the table
    JScrollPane scrollPane;
    
    //Declaring Image Icon that will acess the chronoligcal order png 
    ImageIcon imgChronologicalOrder = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/SortDate.png");
    //Declaring Image Icon that will access the alphabetical order png
    ImageIcon imgAlphabeticalOrder = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/AlphabeticalOrderPng.png");
    
    JLabel lblCircle;
    //Declaring a ImageIcon that will access the Circle
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");
    
  



  
    public frmShowPasswordPage(){
      
       //Set the screen size to 825 x 600
       resize(825,600);
       setLayout(null);
       //Set the background colour to orange
       getContentPane().setBackground(Color.ORANGE);
       
       //Set up and add a JLabel that will add display All Passwords at the top of the screen
       lblShowPasswords = new JLabel();
       lblShowPasswords.setFont(new Font(strFontMono, 1+Font.ITALIC, 24));
       lblShowPasswords.setForeground(Color.white);
       lblShowPasswords.setText("All Passwords: ");
       lblShowPasswords.setSize(400, 60);
       lblShowPasswords.setLocation(287, 10);
       add(lblShowPasswords);
       
       //Set an array called columnNames that will display the coloumns which is Site and Password
       String[] columnNames = {"Site", "Password"};
       
       //Set originalPasswords to DatabaseArrConversion
       originalPasswords1 = DatabaseArrConversion();
       originalPasswords = Login.decryptPassword(originalPasswords1);
       //If the originalPassword isn't empty or it's lenght is greater than 0
       if (originalPasswords != null && originalPasswords.length > 0){
        //Setup a table that will display the originalPasswords as the row data, and coloumns as coloumn names
        table = new JTable(originalPasswords, columnNames);
        table.setFont(new Font(strFontMono, Font.PLAIN, 16));
        table.getTableHeader().setFont(new Font(strFontMono, Font.BOLD, 16));
        table.setRowHeight(25);
        table.setEnabled(false);
        //Add the table to a scrollPane which add a scroll feature if need be , and add it to the screen. 
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100 ,150, 600, 300);
        add(scrollPane);
       }
      
      
        
      
      //Setup and Add a btnSearchSpecificPass that will ask the user if they want to search a specific password, add it to lower portion of the screen
      btnSearchSpecificPass = new JButton();
      btnSearchSpecificPass.setText("Search Specific Password");
      btnSearchSpecificPass.setFont(new Font(strFontSerif, 1+Font.ITALIC, 20));
      btnSearchSpecificPass.setSize(400, 50);
      btnSearchSpecificPass.setLocation(187, 500);
      add(btnSearchSpecificPass);
      //Listen if the user presses the button
      btnSearchSpecificPass.setActionCommand("searchpass");
      btnSearchSpecificPass.addActionListener(this);
      add(btnSearchSpecificPass);
      
      //Setup and Add btnOrder that will ask the user if they want to sort the table
      btnOrder = new JButton();
      btnOrder.setFont(new Font("Serif",1, 17));
      btnOrder.setSize(50, 50);
      btnOrder.setLocation(650, 100);
      btnOrder.setIcon(imgAlphabeticalOrder);
      add(btnOrder);

      btnOrder.setActionCommand("sort");
      btnOrder.addActionListener(this);
      add(btnOrder);
      
      //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
      lblCircle = new JLabel();
      lblCircle.setText("");
      lblCircle.setSize(330, 350);
      lblCircle.setOpaque(false);
      lblCircle.setIcon(imgCircle);
      lblCircle.setLocation(-110, -80);
      add(lblCircle);
      
      //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
      lblCircle2 = new JLabel();
      lblCircle2.setText("");
      lblCircle2.setSize(400,400);
      lblCircle2.setOpaque(false);
      lblCircle2.setIcon(imgCircle2);
      lblCircle2.setLocation(600, 350);
      add(lblCircle2);


      //Set up and add btnExit which will exit and go back to the home screen
      btnExit = new JButton();
      btnExit.setText("↩");
      btnExit.setFont(new Font("Serif",1, 17));
      btnExit.setSize(50, 50);
      btnExit.setLocation(750, 5);
      add(btnExit);

      btnExit.setActionCommand("exit");
      btnExit.addActionListener(this);
      add(btnExit);


    }
    

    
    public void actionPerformed(ActionEvent e){
        
        
      //If the user pressed to search a specific password
      if(e.getActionCommand().equals("searchpass")){
        //Move the user to the frmSearchPasswordPage
        frmSearchPasswordPage frmSearchPasswordPage = new frmSearchPasswordPage(originalPasswords, intIndex);  
        frmSearchPasswordPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmSearchPasswordPage.setSize(825,600);
        frmSearchPasswordPage.setVisible((true));
        //Exit the screen
        this.dispose();
        

       //If the user pressed the sort button
      } else if(e.getActionCommand().equals("sort")){
        
        
        //If boolSortAlpha is true    
        if(boolSortAlpha){
          btnOrder.setIcon(imgChronologicalOrder);
          //Set a 2D array that will get the original passwords
          String[][] passwords = originalPasswords;
          String[][] sortPasswords = new String[intIndex][2];
          //Start a for loop that stop at intIndex, or the last passwords
          for (int i = 0; i < intIndex; i++) {
            //Set the sites field of the new 2D array to the site field of the passwords
            sortPasswords[i][0] = passwords[i][0];
            //Set the passwords field of the new 2D array to the passwords field of the passwords
            sortPasswords[i][1] = passwords[i][1];
          
          }
           //Set an array to temp which will be a temporary placeholder for an index in sortPasswords
           String[] temp;
            //Start a for loop that will index through the length of sortPasswords
            for(int i = 0; i < sortPasswords.length; i++){
              //Start a j loop that will index through the length of sortPasswords
              for(int j = 0; j < sortPasswords.length-i-1; j++){
                //If the sortPasswords at J is greater than sortPasswords at J+1
                if(sortPasswords[j][0].compareTo(sortPasswords[j+1][0]) > 0){
                  //Set temp to sortPasswords at J
                  temp = sortPasswords[j];
                  //Set sortPasswards at J to sortPasswords at J+1
                  sortPasswords[j] = sortPasswords[j+1];
                  //Set sortPasswords at J+1 to J
                  sortPasswords[j+1] = temp;
                }
              }
           }
          //Set up columnNames that will be the coloumn for the table
          String[] columnNames = {"Site", "Password"};
          
          //Setup a new JTable which display the sortPasswords as the rowData, and coloumn Names as Header Fileds
          table = new JTable(sortPasswords, columnNames);
          table.setFont(new Font(strFontMono, Font.PLAIN, 16));
          table.getTableHeader().setFont(new Font("Monospaced", Font.BOLD, 16));
          table.setRowHeight(25);
          //Add the JTable to the screen
          scrollPane = new JScrollPane(table);
          scrollPane.setBounds(100, 150, 600, 300);
          add(scrollPane);
          //Set boolSortAlpha to false
          boolSortAlpha = false; 
          //If boolSortAlpha is false
        } else {
            btnOrder.setIcon(imgAlphabeticalOrder);
            //Set a new coloumNames to Site and Passwords
            String[] columnNames = {"Site", "Password"};
            //Set the data to originalPasswords
            String[][] data = originalPasswords;
            
            //Set a new JTable which display coloumnNames as the header, and the data as the originalPasswords
            table = new JTable(data, columnNames);
            table.setFont(new Font("Monospaced", Font.PLAIN, 16));
            table.getTableHeader().setFont(new Font(strFontMono, Font.BOLD, 16));
            table.setRowHeight(25);
            //Add the table to the screen
            scrollPane = new JScrollPane(table);
            scrollPane.setBounds(100, 150, 600, 300);
            add(scrollPane);
            boolSortAlpha = true;
          
        }
        
      
        
      
        //If the user chooses to exit
      } else if (e.getActionCommand().equals("exit")){
          //Move the user to the frmHomePage
          frmHomePage frmHomePage = new frmHomePage();  
          frmHomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          frmHomePage.setSize(825,600);
          frmHomePage.setVisible((true));
          //Exit the program
          this.dispose();
      }
  
        
       
        
    }
    
}
