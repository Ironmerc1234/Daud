/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;


import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;


public class frmRegisterPage extends JFrame implements ActionListener{
    
    
    //Delcaring a JLabel that will Welcome the User
    JLabel lblRegister;

    // Declaring a JLabel and a JPasswordField for entering the new password 
    JLabel lblPass; 
    JPasswordField txtPass;

    // Declaring two JTextAreas for displaying messages about wrong password and password criteria 
    JTextArea txtWrongPassword; 
    JTextArea txtPasswordCriteria;

    // Declaring a JButton for applying the new password
    JButton btnEnter; 

    // Declaring a JButton for exiting the program
    JButton btnExit; 

    //Declaring a JLabel that will add a Circle
    JLabel lblCircle;
    //Declaring a ImageIcon that will access the Circle
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");

    


    // Declaring a static method that takes a String as a parameter and writes it to a file as the master password
    public static void newMasterPassword(String strPassword){
      try{
        // Creating a FileWriter and a PrintWriter objects to write to the file
        FileWriter fw = new FileWriter("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/MasterPassword.txt");
        PrintWriter pw = new PrintWriter(fw);

        // Writing the password to the file
        pw.println(strPassword);
        // Closing the PrintWriter object
        pw.close();



      } 
      // Catching any IOExceptions that may occur
      catch(IOException e){}

    }

    // Declaring a static method that takes a String as a parameter and checks if it meets the password criteria
    public static boolean checkPassword(String str){
      // Checking if the password length is less than or equal to 12 and returning false if it is
      if (str.length() <= 12){
        return false;
      }

      // Declaring a boolean variable to indicate if the password has a capital letter
      boolean boolHasCapital = false;
      // Looping through the password characters
      for(int i = 0; i < str.length(); i++){
        // Getting the current character
        char ch = str.charAt(i);
        // Checking if the character is between A and Z
        if (ch >= 'A' && ch <= 'Z'){
          // Setting the boolean variable to true
          boolHasCapital = true;
          // Breaking out of the loop
          i = str.length()+1;
        }
      }
      // Checking if the boolean variable is false and returning false if it is
      if(!boolHasCapital){
        return false;
      }

      // Declaring a boolean variable to indicate if the password has a special character
      boolean boolHasSpecialChar = false;
      // Declaring a String with all the possible special characters
      String specialChars = "!@#$%^&*()_+-={}[]|\\:;\"'<>,.?/";

      // Looping through the password characters
      for(int i = 0; i < str.length(); i++){
        // Getting the current character
        char ch = str.charAt(i);
        // Checking if the character is in the specialChars String
        if (specialChars.indexOf(ch) != -1){
          // Setting the boolean variable to true 
          boolHasSpecialChar = true; 
          // Breaking out of the loop
          i = str.length()+1;
        }
      }
      // Checking if the boolean variable is false and returning false if it is
      if(!boolHasSpecialChar){
        return false;
      }

      // Declaring a boolean variable to indicate if the password has a number
      boolean boolHasNumber = false;
      // Declaring a String with all the possible numbers
      String strNum = "1234567890";
      // Looping through the password characters
      for(int i =0; i<str.length(); i++){
        // Getting the current character
        char ch = str.charAt(i);
        // Checking if the character is in the strNum String
        if(strNum.indexOf(ch) != -1){
          // Setting the boolean variable to true
          boolHasNumber = true;
          // Breaking out of the loop
          i = str.length()+1;
        }
      }
      // Checking if the boolean variable is false and returning false if it is
      if(!boolHasNumber){
        return false;
      }
      // Returning true if all the criteria are met 
      return true; 
    }




// Creating a constructor with no parameters
public frmRegisterPage(){
  
    // Setting the size, layout and background color of the frame
    resize(825,600);
    setLayout(null);
    getContentPane().setBackground(Color.ORANGE);

    // Initializing and setting the properties of the register label
    lblRegister = new JLabel();
    lblRegister.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
    lblRegister.setForeground(Color.white);
    lblRegister.setText("Register");
    lblRegister.setSize(600, 100);
    lblRegister.setLocation(412, 10);
    add(lblRegister);

    // Initializing and setting the properties of the password label
    lblPass = new JLabel();
    lblPass.setFont(new Font("Monospaced", 1, 18));
    lblPass.setForeground(Color.black);
    lblPass.setText("New Password"); 
    lblPass.setSize(200, 200);
    lblPass.setLocation(87, 200);
    add(lblPass);

    // Initializing and setting the properties of the password field
    txtPass = new JPasswordField();
    txtPass.setText("");
    txtPass.setSize(350, 50);
    txtPass.setLocation(287, 275);
    add(txtPass);

    // Initializing and setting the properties of the enter button
    btnEnter = new JButton();
    btnEnter.setText("Apply");
    btnEnter.setFont(new Font("Serif", 1+Font.ITALIC, 20));
    btnEnter.setSize(200, 50);
    btnEnter.setLocation(337, 450);
    add(btnEnter);

    // Setting the action command and adding an action listener to the enter button
    btnEnter.setActionCommand("apply");
    btnEnter.addActionListener(this);
    add(btnEnter);

    // Initializing and setting the properties of the password criteria text area
    txtPasswordCriteria = new JTextArea();
    txtPasswordCriteria.setLocation(287, 100);
    txtPasswordCriteria.setSize(500, 100);
    txtPasswordCriteria.setFont(new Font("Times New Roman", 1+Font.ITALIC, 14));
    txtPasswordCriteria.setBackground(new Color(0,0,0,0));
    txtPasswordCriteria.setOpaque(false);
    txtPasswordCriteria.setEditable(false);
    txtPasswordCriteria.setText("•Password must be longer than 12 characters\n•Password must contain at least one special character i.e !, *, $\n•Password must contain at least one upper case letter\n•Password must have number");
    add(txtPasswordCriteria);


    // Initializing and setting the properties of the wrong password text area
    txtWrongPassword = new JTextArea();
    txtWrongPassword.setLocation(287, 200);
    txtWrongPassword.setSize(400, 100);
    txtWrongPassword.setFont(new Font("Times New Roman", 1+Font.ITALIC+Font.BOLD, 17));
    txtWrongPassword.setBackground(new Color(0,0,0,0));
    txtWrongPassword.setOpaque(false);
    txtWrongPassword.setText("");
    add(txtWrongPassword);
    
    //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
    lblCircle = new JLabel();
    lblCircle.setText("");
    lblCircle.setSize(330, 350);
    lblCircle.setOpaque(false);
    lblCircle.setIcon(imgCircle);
    lblCircle.setLocation(-100, -20);
    add(lblCircle);

    //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
    lblCircle2 = new JLabel();
    lblCircle2.setText("");
    lblCircle2.setSize(400,400);
    lblCircle2.setOpaque(false);
    lblCircle2.setIcon(imgCircle2);
    lblCircle2.setLocation(700, 100);
    add(lblCircle2);
      

    // Initializing and setting the properties of the exit button
    btnExit = new JButton();
    btnExit.setText("✖");
    btnExit.setFont(new Font("Serif", 1+Font.ITALIC, 13));
    btnExit.setSize(50, 50);
    btnExit.setLocation(750, 5);
    add(btnExit);

    // Setting the action command and adding an action listener to the exit button
    btnExit.setActionCommand("exit");
    btnExit.addActionListener(this);
    add(btnExit);  
    
}



// Overriding the actionPerformed method to handle button clicks
public void actionPerformed(ActionEvent e){
    if(e.getActionCommand().equals("apply")){
      // Getting the new password from the password field
      String strNewPassword = txtPass.getText();
      // Checking if the new password meets the criteria using the checkPassword method
      if(checkPassword(strNewPassword)){
        // Calling the newMasterPassword method to write the new password to the file
        newMasterPassword(strNewPassword);
        // Creating a frmAccessPage object with true as a parameter and setting its properties
        frmAccessPage frmAccessPage = new frmAccessPage(true);  
        frmAccessPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmAccessPage.setSize(825,600);
        frmAccessPage.setVisible((true));
        // Disposing this frame
        this.dispose();
        
      } else {
        // Setting the text of the wrong password text area to display a message that the password does not meet the criteria
        txtWrongPassword.setText("Supplied Password does \nnot meet password requirements");
        
        
      }

    } else if (e.getActionCommand().equals("exit")){
        frmAccessPage frmAccessPage = new frmAccessPage(false);
        //                                                 
        frmAccessPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmAccessPage.setSize(825,600);
        frmAccessPage.setVisible(true);
        this.dispose();
        
      }
        
       
        
    }
    
}


