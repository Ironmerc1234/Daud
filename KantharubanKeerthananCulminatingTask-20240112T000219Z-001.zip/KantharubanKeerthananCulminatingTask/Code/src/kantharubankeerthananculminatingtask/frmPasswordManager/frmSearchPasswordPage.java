/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;




import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;



public class frmSearchPasswordPage extends JFrame implements ActionListener{
    
    
//Delcaring a JLabel that will Welcome the User
JLabel lblWelcome;

// Declaring a JLabel and a JTextField for the site name
JLabel lblSite; 
JTextField txtSite;

// Declaring a JButton for searching the site name
JButton btnSearch; 

// Declaring a JButton for exiting the program
JButton btnExit;

// Declaring a JTable, a JScrollPane and a DefaultTableModel for displaying the passwords
JTable table;
JScrollPane scrollPane;
DefaultTableModel tableModel;

//Declaring a JLabel that will add a Circle
JLabel lblCircle;
//Declaring a ImageIcon that will access the Circle
ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
//Declaring a JLabel that will add another Circle
JLabel lblCircle2;
//Declaring ImageIcon that will access the Circle
ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");

    

// Declaring a 2D array of Strings to store the passwords and an int to store the index
String[][] arrPassword;
int intIndexPass;








// Creating a constructor that takes a 2D array of Strings and an int as parameters
public frmSearchPasswordPage(String[][] passwords, int intIndex){ 

    // Assigning the parameters to the class variables
    arrPassword = passwords;
    intIndexPass = intIndex;

    // Setting the size, layout and background color of the frame
    resize(825,600);
    setLayout(null);
    getContentPane().setBackground(Color.ORANGE);

    // Initializing and setting the properties of the welcome label
    lblWelcome = new JLabel();
    lblWelcome.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
    lblWelcome.setForeground(Color.white);
    lblWelcome.setText("Search Specific Password");
    lblWelcome.setSize(600, 100);
    lblWelcome.setLocation(187, 10);
    add(lblWelcome);


    // Initializing and setting the properties of the site label
    lblSite = new JLabel();
    lblSite.setFont(new Font("Monospaced", 1, 18));
    lblSite.setForeground(Color.black);
    lblSite.setText("Site Name"); 
    lblSite.setSize(200, 200);
    lblSite.setLocation(87, 50);
    add(lblSite);

    // Initializing and setting the properties of the site text field
    txtSite = new JTextField();
    txtSite.setText("");
    txtSite.setSize(350, 50);
    txtSite.setLocation(287, 125);
    add(txtSite);


    // Initializing and setting the properties of the table model with one column
    String[] strColoumn = {"Passwords"};
    tableModel = new DefaultTableModel(strColoumn, 0);

    // Initializing and setting the properties of the table with the table model
    table = new JTable(tableModel);
    table.setFont(new Font("Monospaced", Font.PLAIN, 16));
    table.getTableHeader().setFont(new Font("Monospaced", Font.BOLD, 16));
    table.setRowHeight(25);
    table.setEnabled(false);

    // Initializing and setting the properties of the scroll pane with the table
    scrollPane = new JScrollPane(table);
    scrollPane.setBounds(100, 200, 600, 250);
    add(scrollPane);
    

  


    // Initializing and setting the properties of the search button
    btnSearch = new JButton();
    btnSearch.setText("Search");
    btnSearch.setFont(new Font("Serif", 1+Font.ITALIC, 20));
    btnSearch.setSize(200, 50);
    btnSearch.setLocation(288, 460);
    add(btnSearch);

    // Setting the action command and adding an action listener to the search button
    btnSearch.setActionCommand("search");
    btnSearch.addActionListener(this);
    add(btnSearch);
    
    //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
    lblCircle = new JLabel();
    lblCircle.setText("");
    lblCircle.setSize(330, 350);
    lblCircle.setOpaque(false);
    lblCircle.setIcon(imgCircle);
    lblCircle.setLocation(-20, 300);
    add(lblCircle);

    //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
    lblCircle2 = new JLabel();
    lblCircle2.setText("");
    lblCircle2.setSize(400,400);
    lblCircle2.setOpaque(false);
    lblCircle2.setIcon(imgCircle2);
    lblCircle2.setLocation(600, 4);
    add(lblCircle2);
      

    // Initializing and setting the properties of the exit button
    btnExit = new JButton();
    btnExit.setText("↩");
    btnExit.setFont(new Font("Serif",1, 17));
    btnExit.setSize(50, 50);
    btnExit.setLocation(750, 5);
    add(btnExit);



    // Setting the action command and adding an action listener to the exit button 
    btnExit.setActionCommand("exit");
    btnExit.addActionListener(this);
    add(btnExit);  

}



// Overriding the actionPerformed method to handle button clicks
public void actionPerformed(ActionEvent e){
    if (e.getActionCommand().equals("search")) {
        // Getting the site name from the text field and converting it to lower case
        String strFindSite = txtSite.getText().toLowerCase();
        // Declaring a boolean variable to indicate if the password is found or not
        boolean passFound = false; 

        // Clearing the table model
        tableModel.setRowCount(0);

        // Looping through the password array
        for (int i = 0; i < intIndexPass; i++) {
            // Converting the site name in the array to lower case
            String arrPasswordLower = arrPassword[i][0].toLowerCase();

            // Checking if the site name in the array contains the site name from the text field
            if (arrPassword[i][0] != null && arrPasswordLower.contains(strFindSite)) {
                // Setting the boolean variable to true
                passFound = true; 
               
                // Creating an array of Strings with the password from the array
                String[] rowData = {arrPassword[i][1]};
                // Adding the row data to the table model
                tableModel.addRow(rowData);
            }
            
            // Checking if the password is not found and it is the last iteration of the loop
            if(!passFound && i == intIndexPass-1){
                // Creating an array of Strings with a message that no password is found
                String[] strNoPassFound = {"No Password Found :("};
                // Adding the row data to the table model
                tableModel.addRow(strNoPassFound);
                    
                    
                }
            }

        //If the user chooses to exit
      } else if (e.getActionCommand().equals("exit")){
        //Take user back to showPasswordPage
        frmShowPasswordPage frmShowPasswordPage = new frmShowPasswordPage();  
        frmShowPasswordPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmShowPasswordPage.setSize(825,600);
        frmShowPasswordPage.setVisible((true));
        //Exit this creen
        this.dispose();
        
      }
    
        
       
        
    }
    
}
