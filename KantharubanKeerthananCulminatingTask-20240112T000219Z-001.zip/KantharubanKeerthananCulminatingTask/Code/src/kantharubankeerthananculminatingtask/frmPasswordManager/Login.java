package kantharubankeerthananculminatingtask.frmPasswordManager;

import java.io.BufferedReader;
import java.security.SecureRandom;
import java.util.regex.Pattern;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JTextField;

public class Login {
	
	private String password;
	private String passwordLower;
	private String site; 
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
 
	
	public Login(String user, String password) {
		this.site = user;
		this.password = password;
		passwordLower = password.toLowerCase();
		
	}
	
	public void setUser(String user) {
		this.site = user;
		
	}
	
	
	public String getUser() {
		return site;
	}
	
	public void setPassword(String passsword) {
		this.password = password;
	}
	
	public String getPassword() {
		return password;
	
	}
	
	public String toString() {
		return site + "," + password;
		
	}
	
	
	

    public void encryptPassword() {
        String encryptedStr = "";

        // Generate a random shift for encryption
        int shift = generateRandomShift();

        for (int i = 0; i < password.length(); i++) {
            char currentChar = password.charAt(i);

            if (Character.isLetter(currentChar)) {
    
                int pos = currentChar;
                int encryptPos = (shift + pos) % 26;
                char encryptChar = (char) ( encryptPos);

                encryptedStr += encryptChar;
            } else if (Character.isDigit(currentChar)) {
                // Encrypt numbers using a simple shift (you can modify this based on your requirements)
                int digit = Character.getNumericValue(currentChar);
                int encryptedDigit = (digit + shift) % 10;
                encryptedStr += Integer.toString(encryptedDigit);
            } else {
                // Non-letter, non-digit characters remain unchanged
                encryptedStr += currentChar;
            }
        }

        // Store the shift with the encrypted password
        password = shift + "::$%*@#;" + encryptedStr;
    }

    public static String[][] decryptPassword(Login[] originalPasswords) {
        String[][] decryptedPasswords = new String[originalPasswords.length][2];
        for (int i = 0; i < originalPasswords.length; i++) {
            decryptedPasswords[i][0] = originalPasswords[i].getUser();
            decryptedPasswords[i][1] = decryptSinglePassword(originalPasswords[i].getPassword());
        }
        return decryptedPasswords;
    }

    public static String decryptSinglePassword(String inputStr) {
        // Split the stored shift and encrypted password
        String[] parts = inputStr.split("::\\$\\%\\*\\@\\#\\;");
        int shift = Integer.parseInt(parts[0]);
        String encryptedStr = parts[1].toLowerCase();
        String decryptedStr = "";

        for (int j = 0; j < encryptedStr.length(); j++) {
            char currentChar = encryptedStr.charAt(j);

            if (Character.isLetter(currentChar)) {
                int pos = ALPHABET.indexOf(currentChar);
                int decryptPos = (pos - shift) % 26;
                if (decryptPos < 0) {
                    decryptPos = ALPHABET.length() + decryptPos;
                }
                char decryptChar = ALPHABET.charAt(decryptPos);

                decryptedStr += decryptChar;
            } else if (Character.isDigit(currentChar)) {
                // Decrypt numbers using a simple shift
                int digit = Character.getNumericValue(currentChar);
                int decryptedDigit = (digit - shift) % 10;
                if (decryptedDigit < 0) {
                    decryptedDigit = 10 + decryptedDigit;
                }
                decryptedStr += Integer.toString(decryptedDigit);
            } else {
                // Non-letter, non-digit characters remain unchanged
                decryptedStr += currentChar;
            }
        }

        return decryptedStr;
    }

    private int generateRandomShift() {
        // Use a secure random number generator
        SecureRandom random = new SecureRandom();
        // Generate a random number between 1 and 25 for the shift
        return random.nextInt(25) + 1;
    }
	public static void samePassword(String user) {
	    String tempFile = "passwordDatabase";
	    File oldFile = new File("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/passwordDatabase.txt");
	    File newFile = new File(tempFile);
	    int intLine = 0;
	
	    try {
	        FileWriter fw = new FileWriter(tempFile, true);
	        BufferedWriter bw = new BufferedWriter(fw);
	        PrintWriter pw = new PrintWriter(bw);
	
	        FileReader fr = new FileReader("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/passwordDatabase.txt");
	        BufferedReader br = new BufferedReader(fr);
	
	        String line = br.readLine();
	
	       while (line != null) {
	            intLine++;
	            if (!line.startsWith(user + ",")) {
	                pw.println(line);
	            } else {
	              
	            }
	            line = br.readLine();
	        }
	
	        pw.flush();
	        pw.close();
	        fr.close();
	        br.close();
	        bw.close();
	        fw.close();
	
	        oldFile.delete();
	        File dump = new File("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/passwordDatabase.txt");
	        newFile.renameTo(dump);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
	}

}
