/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;

 
 
import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class frmHomePage extends JFrame implements ActionListener{
    //Delcaring a JLabel that will Welcome the User
    JLabel lblMenu;
    
    //Declaring a JButton that will ask user if they want to go to frmShowPasswordPage
    JButton btnShowPassword;
    //Declaring a JButton that will ask user if they want to go to frmSetPasswordsPage
    JButton btnSetPassword;
    //Declaring a JButton that will ask the user if they want to go to frmSettingsPage
    JButton btnSettings;
    //Declaring a JButton that will ask the user if they want to exit 
    JButton btnExit;

    
    //Declaring a JLabel that will add a Circle
    JLabel lblCircle;
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");
  
    
    


    public frmHomePage(){
      
      //Set the screen size to 825 by 600
      resize(825,600);
      setLayout(null);
      getContentPane().setBackground(Color.ORANGE);
      
      //Setup and add lblMenu which wil display Menu on the top of the screen
      lblMenu = new JLabel();
      lblMenu.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
      lblMenu.setForeground(Color.white);
      lblMenu.setText("Menu");
      lblMenu.setSize(600, 100);
      lblMenu.setLocation(387, 10);
      add(lblMenu);

      
      //Setup and add btnShowPassword which will display a button below the Menu that will display "Show all Passwords(s)"
      btnShowPassword = new JButton();
      btnShowPassword.setText("Show all Password(s)");
      btnShowPassword.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnShowPassword.setSize(750, 50);
      btnShowPassword.setLocation(28, 200);
      add(btnShowPassword);
      
      btnShowPassword.setActionCommand("showpass");
      btnShowPassword.addActionListener(this);
      add(btnShowPassword);
      
      //Setup and add btnSetPassword which will display a button below btnShowPassword that will display "Set a new Password"
      btnSetPassword = new JButton();
      btnSetPassword.setText("Set a new Password");
      btnSetPassword.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnSetPassword.setSize(750, 50);
      btnSetPassword.setLocation(28, 300);
      add(btnSetPassword);
      
      btnSetPassword.setActionCommand("setpass");
      btnSetPassword.addActionListener(this);
      add(btnSetPassword);
      
      //Setup and add btnSettings which will display a button below btnSetPassword that will display "Settings" 
      btnSettings = new JButton();
      btnSettings.setText("Settings");
      btnSettings.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnSettings.setSize(750, 50);
      btnSettings.setLocation(28, 400);
      add(btnSettings);
      
      btnSettings.setActionCommand("settings");
      btnSettings.addActionListener(this);
      add(btnSettings);
      
      //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
      lblCircle = new JLabel();
      lblCircle.setText("");
      lblCircle.setSize(330, 350);
      lblCircle.setOpaque(false);
      lblCircle.setIcon(imgCircle);
      lblCircle.setLocation(-100, 90);
      add(lblCircle);
      
      //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
      lblCircle2 = new JLabel();
      lblCircle2.setText("");
      lblCircle2.setSize(400,400);
      lblCircle2.setOpaque(false);
      lblCircle2.setIcon(imgCircle2);
      lblCircle2.setLocation(600, 200);
      add(lblCircle2);
      
      //Setup and add a btnExit that will display a button below btnSettings that will display "X"
      btnExit = new JButton();
      btnExit.setText("✖");
      btnExit.setFont(new Font("Serif",0, 12));
      btnExit.setSize(45, 45);
      btnExit.setLocation(750, 5);
      add(btnExit);

      btnExit.setActionCommand("exit");
      btnExit.addActionListener(this);
      add(btnExit);

    }
    

    
    public void actionPerformed(ActionEvent e){
        //If user presses the show all passwords button
      if(e.getActionCommand().equals("showpass")){
        //Move the user to frmShowPasswordPage
        frmShowPasswordPage frmShowPasswordPage = new frmShowPasswordPage();  
        frmShowPasswordPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmShowPasswordPage.setSize(825,600);
        frmShowPasswordPage.setVisible((true));
        //Exit this screen
        this.dispose();
        
        //If the user presses the set passwords button
      } else if (e.getActionCommand().equals("setpass")){

        //Move the user to the frmSetPasswordsPage
        frmSetPasswordPage frmSetPasswordPage = new frmSetPasswordPage();  
        frmSetPasswordPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmSetPasswordPage.setSize(825,600);
        frmSetPasswordPage.setVisible((true));
        //Exit this screen
        this.dispose();
        
        //If the user presses the settings button
      } else if (e.getActionCommand().equals("settings")){
        //Move the user to frmSettingsPage
        frmSettingsPage frmSettingsPage = new frmSettingsPage();  
        frmSettingsPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmSettingsPage.setSize(825,600);
        frmSettingsPage.setVisible((true));
        //Exit this screen
        this.dispose();
        
        //If the user presses the exit button
      } else if (e.getActionCommand().equals("exit")){
          
        //Exit the program with a boolean set true that the user is already a user
        frmAccessPage frmAccessPage = new frmAccessPage(true);              
        frmAccessPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmAccessPage.setSize(825,600);
        frmAccessPage.setVisible(true);
        //Exit this screen
        this.dispose();

        
      }
        
       
        
    }
    
}

