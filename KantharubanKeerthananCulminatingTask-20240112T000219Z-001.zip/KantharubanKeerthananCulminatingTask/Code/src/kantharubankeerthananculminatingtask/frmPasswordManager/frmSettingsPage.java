/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;


import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.Random;



public class frmSettingsPage extends JFrame implements ActionListener{
    //Delcaring a JLabel that will Welcome the User
    JLabel lblWelcome;
    //Creating a JLabel that will display Generate
    JLabel lblGenerate; 
    //Declaring a JLabel that will open ask for passwords
    JLabel lblPass;
    //Declaring a JTextField that will take input of passwords
    JTextField txtPass;
    //Creating textArea where the password will be generated
    JTextArea txtGenerate;
    //Declaring a textArea that will inform the user the password is wrong
    JTextArea txtWrongPassword;
    //Declaring a JButton that will ask the user if they want to apply
    JButton btnApply; 
    //Declaring a JButton that will ask the user if they want to generate
    JButton btnGenerate; 
    //Declaring a JButton that will ask the user if they want exit
    JButton btnExit;
    //Declaring a JLabel that will add a Circle
    JLabel lblCircle;
    //Declaring a ImageIcon that will access the Circle
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");

  
    /**
     * 
     * @param strPassword 
     * 
     */
    public static void newMasterPassword(String strPassword){
      try{
        //Add a fileWriter which will access the file that stores the masterpassword
        FileWriter fw = new FileWriter("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/MasterPassword.txt");
        //Declaring a printWriter that will write into the file
        PrintWriter pw = new PrintWriter(fw);
        //Print into the file the new masterPasswords
        pw.println(strPassword);
        //Close the file
        pw.close();
        
        
        
      } 
      catch(IOException e){}
      
    }
    
    /**
     * 
     * @param str
     * @return a boolean that will return true if criteria is met
     */
    public static boolean checkPassword(String str){
      //If the length of the word is longer than less than 12 characters 
      if (str.length() <= 12){
        //Return false
        return false;
      }
      //Set a boolean boolHasCapital to false
      boolean boolHasCapital = false;
      //Parse through the length of str
      for(int i = 0; i < str.length(); i++){
        //Look through every letter of the string
        char ch = str.charAt(i);
        //If the letter is capital
        if (ch >= 'A' && ch <= 'Z'){
          //Set boolHasCapital true, meaning it has a capital
          boolHasCapital = true;
          //End the for loop by setting i to the str.lengh+1
          i = str.length()+1;
        }
      }
      //If the bool is still false
      if(!boolHasCapital){
        //Return false
        return false;
      }
      
      //Set a boolean boolHasSpecialChar to false
      boolean boolHasSpecialChar = false;
      //Set a string of specialChars that contains all the special characters
      String specialChars = "!@#$%^&*()_+-={}[]|\\:;\"'<>,.?/";
      
      //Setup a for loop that will index through the string length
      for(int i = 0; i < str.length(); i++){
        //Look through each letter of the str
        char ch = str.charAt(i);
        //If the letters is aparts of special chars
        if (specialChars.indexOf(ch) != -1){
          //Set the boolHasSpecialChar to true, meaning it does have a special character
          boolHasSpecialChar = true;
          //Set i to the length of string which will end the loop
          i = str.length()+1;
        }
      }
      //If the boolHasSpecialChar is still false
      if(!boolHasSpecialChar){
        //Return false
        return false;
      }
      //Setup a boolean name boolHasNumber to be false
      boolean boolHasNumber = false;
      //Set a string to strNum that contains all the numbers
      String strNum = "1234567890";
      //Start a for loop that will index through the length of the string
      for(int i =0; i<str.length(); i++){
        //Look through each letter of the char
        char ch = str.charAt(i);
        //If the ch contains a number
        if(strNum.indexOf(ch) != -1){
          //Set boolHasNumber to true which means there is a number
          boolHasNumber = true;
          //Set i to the length of the string + 1 which will end the loop
          i = str.length()+1;
        }
      }
      //If boolHasNumber is still false
      if(!boolHasNumber){
        //Return true 
        return false;
      }
      //If all cases are passed, return true
      return true; 
    }

    public static String generatePassword(){
      //Start a new Random 
      Random random = new Random();
      
      //Set a string to specialChars which will be randomly choosen
      String specialChars = "!@#$%^&*()_+-={}[]|\\:;\"'<>,.?/"; 
      //Set a string to strNum which will be randomly choosen
      String strNum = "1234567890";
      //Set a string to strAlphabet which will be randomly choosen
      String strAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
      //Set a string to randomLimit which which will generate the length of passwords (between 20 and 12) 
      int randomLimit = random.nextInt(20-12)+12;
      //Set a string to strPassword which be the place where the password is entered into
      String strPassword = "";
      
      //While the strPassword length is greater than the limit
      while(strPassword.length() < randomLimit){
        //Generate a random number from 1 to 3 which will choose speicalChars, strNum, or strAlphabet
        int randomInt = random.nextInt(3);
        //Generate a random number which is the length of specialChars
        int randomSpecialChar = random.nextInt(specialChars.length());
        //Generate a random number which is the length of strNum
        int randomNum = random.nextInt(strNum.length());
        //Generate a random number which is the length of random letter
        int randomLetter = random.nextInt(strAlphabet.length());
        
        //If the randomInt is 1
        if(randomInt == 1){
          //Add the random character at special chars 
          strPassword += specialChars.charAt(randomSpecialChar);
          //If the random int is 2
        } else if (randomInt == 2){
          //Add the random character at str num
          strPassword += strNum.charAt(randomNum);
          //else
        } else{
          //Add the random character at strAlphabet
          strPassword += strAlphabet.charAt(randomLetter);
          
        }
        
      }
      //Return the strPassword
      return strPassword;
      
      
      
    }

  

 
    

  
    public frmSettingsPage(){
      
      //Set the size of window to 825 by 600
      resize(825,600);
      setLayout(null);
      //Set the backgrounds colours of the window to Orange
      getContentPane().setBackground(Color.ORANGE);
      
      //Set a lblWelcome JLabel that will display settings at the top of the screen
      lblWelcome = new JLabel();
      lblWelcome.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
      lblWelcome.setForeground(Color.white);
      lblWelcome.setText("Settings ⚙️");
      lblWelcome.setSize(600, 100);
      lblWelcome.setLocation(362, 10);
      add(lblWelcome);
      
      //Setup and add a lblPass JLabel that will ask the user for a new master passwords
      lblPass = new JLabel();
      lblPass.setFont(new Font("Monospaced", 1, 18));
      lblPass.setForeground(Color.black);
      lblPass.setText("New Master Password"); 
      lblPass.setSize(400, 200);
      lblPass.setLocation(65, 100);
      add(lblPass);
      
      //Setup and add a txtPass JTextField that will read input of the new Master PAssword 
      txtPass = new JTextField();
      txtPass.setText("");
      txtPass.setSize(350, 50);
      txtPass.setLocation(287, 175);
      add(txtPass);

      btnApply = new JButton();
      btnApply.setText("Apply");
      btnApply.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnApply.setSize(150, 50);
      btnApply.setLocation(650, 175);
      add(btnApply);

      btnApply.setActionCommand("apply");
      btnApply.addActionListener(this);
      add(btnApply);
      
      //Setup and add a lblGenerate JLabel that will ask the user to generate a passwords
      lblGenerate = new JLabel();
      lblGenerate.setFont(new Font("Monospaced", 1, 18));
      lblGenerate.setForeground(Color.black);
      lblGenerate.setText("Generate Password"); 
      lblGenerate.setSize(200, 200);
      lblGenerate.setLocation(87, 250);
      add(lblGenerate);
      
      //Setup and add a txtGenerate text area that will display the random passwords
      txtGenerate = new JTextArea();
      txtGenerate.setText("");
      txtGenerate.setFont(new Font("Monospaced", 1, 25));
      txtGenerate.setEditable(false);
      txtGenerate.setSize(350, 50);
      txtGenerate.setLocation(287, 325);
      add(txtGenerate);
      
      //Setup and add a generate button that will generate the passwords when clicked 
      btnGenerate = new JButton();
      btnGenerate.setText("Generate");
      btnGenerate.setFont(new Font("Serif", 1+Font.ITALIC, 20));
      btnGenerate.setSize(150, 50);
      btnGenerate.setLocation(650, 325);
      add(btnGenerate);

      btnGenerate.setActionCommand("generate");
      btnGenerate.addActionListener(this);
      add(btnGenerate);
      
      //If the password the user inputted is wrong, set the JTextArea above it to say it is wrong
      txtWrongPassword = new JTextArea();
      txtWrongPassword.setLocation(287, 230);
      txtWrongPassword.setSize(500, 100);
      txtWrongPassword.setFont(new Font("Monospaced", 1, 15));
      txtWrongPassword.setBackground(new Color(0,0,0,0));
      txtWrongPassword.setOpaque(false);
      txtWrongPassword.setText("");
      add(txtWrongPassword);
      
      //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
      lblCircle = new JLabel();
      lblCircle.setText("");
      lblCircle.setSize(330, 350);
      lblCircle.setOpaque(false);
      lblCircle.setIcon(imgCircle);
      lblCircle.setLocation(-20, 40);
      add(lblCircle);

      //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
      lblCircle2 = new JLabel();
      lblCircle2.setText("");
      lblCircle2.setSize(400,400);
      lblCircle2.setOpaque(false);
      lblCircle2.setIcon(imgCircle2);
      lblCircle2.setLocation(650, 300);
      add(lblCircle2);

      //Add btnExit button that will return to home screen when clicked
      btnExit = new JButton();
      btnExit.setText("↩");
      btnExit.setFont(new Font("Serif",1, 17));
      btnExit.setSize(50, 50);
      btnExit.setLocation(750, 5);
      add(btnExit);

      btnExit.setActionCommand("exit");
      btnExit.addActionListener(this);
      add(btnExit);


        
        
        
    }
    

    
    public void actionPerformed(ActionEvent e){
      //If the user clicks apply
      if(e.getActionCommand().equals("apply")){
        //Set a new string called strNewPassword to the converted string of txtPassword
        String strNewPassword = txtPass.getText();
        //If checkPassword validates the strNewPassword can be ued
        if(checkPassword(strNewPassword)){
          //Set txtWrongPassword to nothing
          txtWrongPassword.setText("");
          //Make the new password strNewPassword
          newMasterPassword(strNewPassword);
        //If this cae fails
        } else {
            //Set txtWrongPasswords to an error message
            txtWrongPassword.setText("Supplied Password does not meet password requirements");
        }
        //If the user chooses to generate a new passwords
      } else if (e.getActionCommand().equals("generate")){
          //Set the text to a generatePasswords
          txtGenerate.setText(generatePassword());
          
        //If the user chooses to exit
      } else if (e.getActionCommand().equals("exit")){
          //Take them back to the home page
          frmHomePage frmHomePage = new frmHomePage();  
          frmHomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          frmHomePage.setSize(825,600);
          frmHomePage.setVisible((true));
          //Exit this creen
          this.dispose();
        
      }
        
        
  
      
        
       
        
    }
    
}
