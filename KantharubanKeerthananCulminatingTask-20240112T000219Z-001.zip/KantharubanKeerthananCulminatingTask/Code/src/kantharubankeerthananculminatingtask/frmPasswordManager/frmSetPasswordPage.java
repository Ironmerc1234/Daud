/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kantharubankeerthananculminatingtask.frmPasswordManager;


import javax.swing.ImageIcon; 

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;


public class frmSetPasswordPage extends JFrame implements ActionListener{
    /**
     * 
     * @param strSite site input
     * @param strPassword password input
     */
	
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    //Delcaring a JLabel that will Welcome the User
    JLabel lblSetPassword;
    
    //Declaring a JLabel that will Provide context to what the site is
    JLabel lblSite;
    //Declaring a JLabel that will take input of the site
    JTextField txtSite; 
    
    //Declaring a JLabel that will Provide contact to what the passwords is
    JLabel lblPass; 
    //Declaring a JLabel that will take input of the passwords
    JTextField txtPass;
    //
    JButton btnEnter; 
    JButton btnExit; 

    //Declaring a JLabel that will add a Circle
    JLabel lblCircle;
    //Declaring a ImageIcon that will access the Circle
    ImageIcon imgCircle = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle.png");
    //Declaring a JLabel that will add another Circle
    JLabel lblCircle2;
    //Declaring ImageIcon that will access the Circle
    ImageIcon imgCircle2 = new ImageIcon("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/images/WhiteCircle2.png");

    
    public static void setPassword(Login tempLogin){
        try{
          //Open the file that stores all the passwords
          FileWriter fw = new FileWriter("/Users/keerthanankantharuban/Desktop/KantharubanKeerthananCulminatingTask/Code/src/kantharubankeerthananculminatingtask/frmPasswordManager/fileDatabase/passwordDatabase.txt", true);
          //Start new print writer
          PrintWriter pw = new PrintWriter(fw);
          //Add in the strSite, and strPassword to the password Database
          pw.println(tempLogin);
          //Close the print writer
          pw.close();
          
          
          
        } 
        catch(IOException e){}
        
 
      }
    
    


 

    
    

  
// Creating a constructor with no parameters
public frmSetPasswordPage(){
  
    // Setting the size, layout and background color of the frame
    resize(825,600);
    setLayout(null);
    getContentPane().setBackground(Color.ORANGE);

    // Initializing and setting the properties of the set password label
    lblSetPassword = new JLabel();
    lblSetPassword.setFont(new Font("Monospaced", 1+Font.ITALIC, 24));
    lblSetPassword.setForeground(Color.white);
    lblSetPassword.setText("Set a new Password");
    lblSetPassword.setSize(600, 100);
    lblSetPassword.setLocation(287, 10);
    add(lblSetPassword);

    // Initializing and setting the properties of the site label
    lblSite = new JLabel();
    lblSite.setFont(new Font("Monospaced", 1, 18));
    lblSite.setForeground(Color.black);
          // Setting the text of the site label
    lblSite.setText("Site"); 
    // Setting the size and location of the site label
    lblSite.setSize(200, 200);
    lblSite.setLocation(87, 75);
    // Adding the site label to the frame
    add(lblSite);

    // Initializing and setting the properties of the site text field
    txtSite = new JTextField();
    txtSite.setText("");
    txtSite.setSize(350, 50);
    txtSite.setLocation(287, 150);
    // Adding the site text field to the frame
    add(txtSite);


    // Initializing and setting the properties of the password label
    lblPass = new JLabel();
    lblPass.setFont(new Font("Monospaced", 1, 18));
    lblPass.setForeground(Color.black);
    // Setting the text of the password label
    lblPass.setText("Password"); 
    // Setting the size and location of the password label
    lblPass.setSize(200, 200);
    lblPass.setLocation(87, 200);
    // Adding the password label to the frame
    add(lblPass);

    // Initializing and setting the properties of the password text field
    txtPass = new JTextField();
    txtPass.setText("");
    txtPass.setSize(350, 50);
    txtPass.setLocation(287, 275);
    // Adding the password text field to the frame
    add(txtPass);

    // Initializing and setting the properties of the enter button
    btnEnter = new JButton();
    btnEnter.setText("Apply");
    btnEnter.setFont(new Font("Serif", 1+Font.ITALIC, 20));
    btnEnter.setSize(200, 50);
    btnEnter.setLocation(337, 450);
    // Adding the enter button to the frame
    add(btnEnter);

    // Setting the action command and adding an action listener to the enter button
    btnEnter.setActionCommand("enter");
    btnEnter.addActionListener(this);
    add(btnEnter);
    
    //Set up and add lblCircle that will add the imgCircle to the upper right of the screen
    lblCircle = new JLabel();
    lblCircle.setText("");
    lblCircle.setSize(330, 350);
    lblCircle.setOpaque(false);
    lblCircle.setIcon(imgCircle);
    lblCircle.setLocation(-20, -10);
    add(lblCircle);

    //Set up and add lblCircle2 that will add the imgcircle to the lower left of the screen
    lblCircle2 = new JLabel();
    lblCircle2.setText("");
    lblCircle2.setSize(400,400);
    lblCircle2.setOpaque(false);
    lblCircle2.setIcon(imgCircle2);
    lblCircle2.setLocation(600, 300);
    add(lblCircle2);
      

    // Initializing and setting the properties of the exit button
    btnExit = new JButton();
    btnExit.setText("↩");
    btnExit.setFont(new Font("Serif",1, 17));
    btnExit.setSize(50, 50);
    btnExit.setLocation(750, 5);

    // Setting the action command and adding an action listener to the exit button
    btnExit.setActionCommand("exit");
    btnExit.addActionListener(this);
    // Adding the exit button to the frame
    add(btnExit);



   }


   // Overriding the actionPerformed method to handle button clicks
   public void actionPerformed(ActionEvent e){
       if(e.getActionCommand().equals("enter")){
         // Getting the site and password from the text fields
         String strSite = txtSite.getText();
         String strPass = txtPass.getText();
         
         Login tempLogin = new Login(strSite, strPass);
         
         tempLogin.encryptPassword();
         
         
         // Calling the passwordSame method to delete any existing password for the same site
         Login.samePassword(tempLogin.getPassword());         // Calling the setPassword method to write the new site and password pair to the file
         setPassword(tempLogin);  
       } else if (e.getActionCommand().equals("exit")){
         // Creating a frmHomePage object and setting its properties
         frmHomePage frmHomePage = new frmHomePage();  
         frmHomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frmHomePage.setSize(825,600);
         frmHomePage.setVisible((true));
         // Disposing this frame
         this.dispose();
       }



   }

    
}
