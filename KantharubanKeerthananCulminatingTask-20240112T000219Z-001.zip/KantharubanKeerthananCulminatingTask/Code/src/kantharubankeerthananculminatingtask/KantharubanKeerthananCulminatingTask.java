/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kantharubankeerthananculminatingtask;

/**
Author: Keerthanan Kantharuban
Date: Jun 8-16, 2023
Password Manager
**/

import kantharubankeerthananculminatingtask.frmPasswordManager.frmAccessPage;
import javax.swing.*;
import java.io.*;
class KantharubanKeerthananCulminatingTask {
  
  public static void main(String[] args) {
    //Call frmAccessPage to show login screen when user runs
    frmAccessPage frmAccessPage = new frmAccessPage(false);
                                                           
    frmAccessPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frmAccessPage.setSize(825,600);
    frmAccessPage.setVisible(true);

    
  }
  
}
